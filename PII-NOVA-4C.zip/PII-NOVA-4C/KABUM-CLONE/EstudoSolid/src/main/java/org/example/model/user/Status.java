package org.example.model.user;

public class Status {
    public enum StatusDatabase {
        HABILITADO,
        DESABILITADO
    }
}
