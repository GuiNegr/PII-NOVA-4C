package org.example;


import org.example.view.interfacePortugues.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
    }
}