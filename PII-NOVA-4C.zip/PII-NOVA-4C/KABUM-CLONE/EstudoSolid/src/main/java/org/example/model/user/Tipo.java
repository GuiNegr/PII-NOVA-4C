package org.example.model.user;

public class Tipo {

    public enum Grupo {
        ESTOQUISTA,
        ADMINISTRADOR
    }
}
